Help function(Task 1, Kayla):

How To Execute:

In the command line, type ./extfat -(option).
   The following options are:
   i: takes the input file name as an argument.
   o: takes the output file name as an argument. If no filename is provided, it will output file name will be the same as the input file name.
   c: the input file is copied to the output file without change.
   m: access the file with mmap().
   f: access the file with fread().
   v: takes an input file name as an argument. The main and backup boot sectors will be read and checked to see if they are the same. if they are not the same, an error message will be written to stdout.



