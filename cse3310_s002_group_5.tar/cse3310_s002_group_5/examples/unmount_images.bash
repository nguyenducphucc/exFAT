#!/bin/bash
# This script will unmount an image
