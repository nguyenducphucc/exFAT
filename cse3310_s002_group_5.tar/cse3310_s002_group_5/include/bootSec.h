#pragma once

int cmp_struct(Main_Boot* MB, Main_Boot* BB);
void bootCheck(Option op);