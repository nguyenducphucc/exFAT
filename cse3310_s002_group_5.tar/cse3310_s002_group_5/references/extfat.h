#pragma once

/* ensure this header can be used in a C++ program */
#ifdef __cplusplus

extern "C"
{
#endif

    // This header defines the layout of data on an extfat disk image.
    
    // For the details, please refer to

    //            https://learn.microsoft.com/en-gb/windows/win32/fileio/exfat-specification
    
    //kayla's code///////////
        struct Option{
    char *inputFile;
    char *outputFile;
    int outputFlag;
    int helpFlag;
    int copyFlag;
    char *verify;
    int mmapFlag;
    int freadFlag;
    };
/////////////////////////////
    typedef struct
    {
        char JumpBoot[3];
        char FileSystemName[8];
        char MustBeZero[53];
        long int PartitionOffset;
        long int VolumeLength;
        int FatOffset;
        int FatLength;
        int ClusterHeapOffset;
        int ClusterCount;
        int FirstClusterOfRootDirectory;
        int VolumeSerialNumber;
        short int FileSystemRevision;
        short int VolumeFlags;
        unsigned char BytesPerSectorShift;
        unsigned char SectorsPerClusterShift;
        unsigned char NumberOfFats;
        unsigned char DriveSelect;
        unsigned char PercentInUse;
        unsigned char Reserved[7];
        unsigned char BootCode[390];
        short int BootSignature;
        unsigned char ExcessSpace;
    } Main_Boot;
  

#ifdef __cplusplus
    extern "C"
};
#endif